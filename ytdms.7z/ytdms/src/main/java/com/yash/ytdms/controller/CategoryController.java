package com.yash.ytdms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ytdms.model.Category;
import com.yash.ytdms.model.Member;
import com.yash.ytdms.service.CategoryService;

/**
 * Used for the services that are related to Categories
 * 
 * @author goyal.ayush
 *
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/categories")
public class CategoryController {

	@Autowired
	private CategoryService categoryService;
	@Autowired
	private Member loggedInUser;

	/**
	 * 
	 * @param sectionId
	 * @return All the categories that are under a specific section based on
	 *         section id
	 * @throws IOException
	 */
	@GetMapping(value = "/bySectionId/{sectionId}")
	public List<Category> getCategoriesBySectionId(@PathVariable int sectionId)
			throws IOException {
		List<Category> categories = categoryService
				.getCategoriesBySectionId(sectionId);
		return categories;
	}

	/**
	 * Check if category with this name exists, Add Category in DB and make
	 * category name folder under section name folder
	 * 
	 * @param category
	 * @param session
	 * @param response
	 * @param request
	 * @throws IOException
	 */
	@PostMapping("/")
	@ResponseBody
	public void saveCategory(@RequestBody Category category,
			HttpSession session, HttpServletResponse response,
			HttpServletRequest request) throws IOException {
		if (category.getName().contains(" ")) {
			response.getWriter().append("containSpace");
			return;
		}
		if (categoryService.checkIfCategoryExists(category.getName(),
				category.getSection_id())) {
			response.getWriter().append("categoryExists");
			return;
		}
		category.setCreatedBy(loggedInUser.getId());
		category.setModifiedBy(loggedInUser.getId());
		String workingDir = request.getServletContext().getRealPath("");
		categoryService.makeCategoryNameFolder(workingDir,
				category.getSection_id(), category.getName());
		categoryService.addCategory(category);
		/*
		 * List listOfCategoryObjectAndTotalCategories =
		 * getListOfCategoryObjectAndTotalCategories(category); String
		 * jsonOfCategory = new Gson()
		 * .toJson(listOfCategoryObjectAndTotalCategories);
		 * response.setContentType("application/json");
		 * response.getWriter().append(jsonOfCategory);
		 */
	}

}

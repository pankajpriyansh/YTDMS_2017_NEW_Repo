package com.yash.ytdms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ytdms.model.BatchMemberDocumentGraphData;
import com.yash.ytdms.model.DocumentsRequest;
import com.yash.ytdms.model.Member;
import com.yash.ytdms.model.SectionCategoryDocumentGraphData;
import com.yash.ytdms.service.CommonService;
import com.yash.ytdms.service.DocumentService;

/**
 * Used for the services that are related to Trainer.
 * 
 * @author goyal.ayush
 *
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/trainer")
public class TrainerController {

	@Autowired
	private CommonService commonService;

	@Autowired
	private DocumentService documentService;
	
	@Autowired	
	private Member loggedInUser;

	/**
	 * 
	 * @param batchId
	 * @param response
	 * @return data that will be used to create a 3d graph between sectionName ,
	 *         totalCatergories and totalDocuments
	 * @throws IOException
	 */
	@GetMapping(value = "/getSectionCategoryDocumentGraphData/{batchId}")
	public List<SectionCategoryDocumentGraphData> getSectionCategoryDocumentGraphData(
			@PathVariable int batchId, HttpServletResponse response)
			throws IOException {
		List<SectionCategoryDocumentGraphData> list = commonService
				.getSectionCategoryDocumentGraphData(batchId);
		return list;
	}

	/**
	 * 
	 * @param response
	 * @return data that will be used to create a 3d graph between batchName ,
	 *         totalMembers and totalDocuments
	 * @throws IOException
	 */
	@RequestMapping(value = "/getBatchMemberGraphData")
	public List<BatchMemberDocumentGraphData> getBatchMemberDocumentGraphData(
			HttpServletResponse response) throws IOException {
		List<BatchMemberDocumentGraphData> list = commonService
				.getBatchMemberGraphData();
		return list;
	}

	/**
	 * 
	 * @param session
	 * @param modelMap
	 * @return documentsRequest that is made by trainee to have access for
	 *         documents just for himself/herself
	 * @throws IOException
	 */
	@RequestMapping(value = "/documentsRequest")
	public List documentsRequest(HttpSession session) throws IOException {
		return documentService.getRequestedDocumentsData(loggedInUser.getId());
	}

	/**
	 * Approve request of trainee for accessing the documents requested by
	 * him/her. the documents displayed to trainee for 2 days
	 * 
	 * @param documentsRequest
	 * @throws IOException
	 */
	@RequestMapping(value = "/approveRequestForDocument/{requestId}")
	@ResponseBody
	public void approveRequestForDocument(
			@RequestBody DocumentsRequest documentsRequest) throws IOException {

		List<Integer> documentsId = documentService
				.getDocumentsIdListFromDocumentsRequestId(documentsRequest
						.getId());
		documentService.approveRequestForDocument(documentsRequest.getId(),
				documentsId, documentsRequest.getFromUserId());

	}

	/**
	 * Reject request of trainee for accessing the documents requested by
	 * him/her. the trainer should give a reason to Reject
	 * 
	 * @param documentsRequest
	 * @throws IOException
	 */
	@RequestMapping(value = "/saveReasonForRejectionOfRequest")
	@ResponseBody
	public void saveReasonForRejectionOfRequest(
			@RequestBody DocumentsRequest documentsRequest) throws IOException {
		documentService.saveReasonForRejectionOfRequest(
				documentsRequest.getId(), documentsRequest.getRejectedReason());
	}

	/**
	 * 
	 * @param session
	 * @return documentsRequest History made by trainees to access the documents
	 *         he/she want to study
	 * @throws IOException
	 */
	@RequestMapping(value = "/documentRequestReports")
	public List documentRequestReports(HttpSession session) throws IOException {
		return documentService
				.getRequestedDocumentReportsBasicData(loggedInUser.getId());

	}

	/**
	 * 
	 * @param fromUserId
	 * @param toUserId
	 * @return status History of the documentsRequest made by trainees to access
	 *         the documents he/she want to study
	 * @throws IOException
	 */
	@RequestMapping(value = "/documentRequestReportsAdvanceData/{fromUserId}/{toUserId}")
	@ResponseBody
	public List getRequestedDocumentReportsAdvanceData(
			@PathVariable int fromUserId, @PathVariable int toUserId)
			throws IOException {
		List list = documentService.getRequestedDocumentReportsAdvanceData(
				fromUserId, toUserId);
		return list;
	}

}

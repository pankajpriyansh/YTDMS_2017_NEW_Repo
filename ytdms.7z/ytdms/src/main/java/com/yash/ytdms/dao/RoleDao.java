package com.yash.ytdms.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.yash.ytdms.model.Role;

/**
 * 
 * @author goyal.ayush
 *
 */
@Repository
public interface RoleDao {

	List<Role> getAllRoles();

	Role getRoleById(int id);

}

package com.yash.ytdms.daoJdbcImpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.yash.ytdms.dao.SectionDao;
import com.yash.ytdms.model.Section;

/**
 * SectionDaoImpl is the JDBC implementation of all the CRUD operations related
 * to Section
 * 
 * @author goyal.ayush
 *
 */
@Repository
public class SectionDaoImpl implements SectionDao {

	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;

	public DataSource getDataSource() {
		return dataSource;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public List<Section> getAllSections() {
		return jdbcTemplate.query("select * from sections",
				new SectionRowMapper());
	}

	private static final class SectionRowMapper implements RowMapper<Section> {

		public Section mapRow(ResultSet resultSet, int rowNum)
				throws SQLException {
			Section section = new Section();
			section.setId(resultSet.getInt("id"));
			section.setName(resultSet.getString("name"));
			return section;
		}
	}

	@Override
	public List<Section> getSectionsByBatchId(int batchId) {
		return jdbcTemplate
				.query("SELECT * FROM sections WHERE id IN(SELECT section_id FROM categories WHERE id IN (SELECT category_id FROM documents WHERE batch_id=?))",
						new Object[] { batchId }, new SectionRowMapper());
	}

	@Override
	public int getCourseCompletionPercentage(int sectionId, int userId,
			int batchId) {
		try {
			int totalDocumentsUnderThisSection = jdbcTemplate
					.queryForObject(
							"SELECT COUNT(id) FROM documents WHERE batch_id = ? AND category_id IN(SELECT id FROM categories WHERE section_id = ?)",
							new Object[] { batchId, sectionId }, Integer.class);

			System.out.println("totalDocumentsUnderThisSection  "
					+ totalDocumentsUnderThisSection);

			int totalDocumentsReadByUserUnderThisSection = jdbcTemplate
					.queryForObject(
							"SELECT COUNT(*) FROM members_documents_junction WHERE user_id = ? AND document_id IN (SELECT id FROM documents WHERE batch_id = ? AND category_id IN(SELECT id FROM categories WHERE section_id = ?))",
							new Object[] { userId, batchId, sectionId },
							Integer.class);

			System.out.println("totalDocumentsReadByUserUnderThisSection  "
					+ totalDocumentsReadByUserUnderThisSection);

			float percentage = (totalDocumentsReadByUserUnderThisSection * 100)
					/ totalDocumentsUnderThisSection;

			System.out.println("percentage  " + percentage);

			return (int) percentage;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public List<Section> getSectionsByUserId(int userId) {
		return jdbcTemplate
				.query("SELECT * FROM sections WHERE id IN(SELECT section_id FROM categories WHERE id IN (SELECT category_id FROM documents WHERE user_id=?))",
						new Object[] { userId }, new SectionRowMapper());
	}

	@Override
	public boolean checkIfSectionExists(String name) {
		try {
			jdbcTemplate.queryForObject(
					"select name from sections where name=?",
					new Object[] { name }, String.class);
			return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return false;
	}

	@Override
	public void addSection(Section section) {

		jdbcTemplate
				.update("INSERT INTO sections(NAME,createdby,modifiedby,createddate,modifiedDate) VALUES(?,?,?,?,?)",
						new Object[] { section.getName(),
								section.getCreatedBy(),
								section.getModifiedBy(),
								new Timestamp(new Date().getTime()),
								new Timestamp(new Date().getTime()) });

	}

	@Override
	public String getSectionNameBySectionId(int sectionId) {
		return jdbcTemplate.queryForObject(
				"select name from sections where id = ? ",
				new Object[] { sectionId }, String.class);
	}

}

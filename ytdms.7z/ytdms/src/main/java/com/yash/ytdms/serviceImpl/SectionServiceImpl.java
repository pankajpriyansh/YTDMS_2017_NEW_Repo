package com.yash.ytdms.serviceImpl;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ytdms.dao.SectionDao;
import com.yash.ytdms.model.Section;
import com.yash.ytdms.service.SectionService;

/**
 * SectionServiceImpl is the implementation of all the services and
 * functionalities related to Section. It contains all the services related to
 * business logics. Whenever there is a need of database , it can have a call to
 * DAO , to fulfill the need.
 * 
 * @author goyal.ayush
 *
 */
@Service
public class SectionServiceImpl implements SectionService {

	@Autowired
	private SectionDao sectionDao;

	public List<Section> getAllSections() {
		return sectionDao.getAllSections();
	}

	@Override
	public List<Section> getSectionsByBatchId(int batchId) {
		List<Section> sections = sectionDao.getSectionsByBatchId(batchId);
		return sections;
	}

	@Override
	public int getCourseCompletionPercentage(int sectionId, int userId,
			int batchId) {
		return sectionDao.getCourseCompletionPercentage(sectionId, userId,
				batchId);
	}

	@Override
	public List<Section> getSectionsByUserId(int userId) {
		List<Section> sections = sectionDao.getSectionsByUserId(userId);
		return sections;
	}

	@Override
	public boolean checkIfSectionExists(String name) {
		return sectionDao.checkIfSectionExists(name);
	}

	@Override
	public void makeSectionNameFolder(String workingDir, String name) {

		System.out.println("Current working directory : " + workingDir);
		File pathToMakeSectionDir = new File(workingDir + File.separator + ".."
				+ File.separator + "ytdms-cli" + File.separator + "assets"
				+ File.separator + "Documents" + File.separator + name);
		if (!pathToMakeSectionDir.exists()) {
			pathToMakeSectionDir.mkdirs();
		}

	}

	@Override
	public void addSection(Section section) {
		sectionDao.addSection(section);
	}

	@Override
	public String getSectionNameBySectionId(int sectionId) {
		return sectionDao.getSectionNameBySectionId(sectionId);
	}

}

package com.yash.ytdms.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ytdms.dao.CommonDao;
import com.yash.ytdms.model.BatchMemberDocumentGraphData;
import com.yash.ytdms.model.SectionCategoryDocumentGraphData;
import com.yash.ytdms.service.CommonService;

/**
 * 
 * @author goyal.ayush
 *
 */
@Service
public class CommonServiceImpl implements CommonService {

	@Autowired
	private CommonDao commonDao;

	@Override
	public List<SectionCategoryDocumentGraphData> getSectionCategoryDocumentGraphData(
			int batchId) {
		return commonDao.getSectionCategoryDocumentGraphData(batchId);
	}

	@Override
	public List<BatchMemberDocumentGraphData> getBatchMemberGraphData() {
		return commonDao.getBatchMemberGraphData();
	}

}

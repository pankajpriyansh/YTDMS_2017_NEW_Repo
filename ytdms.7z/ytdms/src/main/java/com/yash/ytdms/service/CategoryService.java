package com.yash.ytdms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.yash.ytdms.model.Category;

/**
 * CategoryService provides all the services and functionalities related to
 * category. This is the design, implemented by any specific implementation
 * provider . It contains all the services related to business logics .
 * 
 * @author goyal.ayush
 *
 */
@Service
public interface CategoryService {

	List<Category> getCategoriesBySectionId(int sectionId);

	boolean checkIfCategoryExists(String name, int section_id);

	void makeCategoryNameFolder(String workingDir, int section_id, String name);

	void addCategory(Category category);

}

package com.yash.ytdms.daoJdbcImpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.yash.ytdms.dao.CategoryDao;
import com.yash.ytdms.model.Category;

/**
 * CategoryDaoImpl is the JDBC implementation of all the CRUD operations related
 * to category
 * 
 * @author goyal.ayush
 *
 */
@Repository
public class CategoryDaoImpl implements CategoryDao {

	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;

	public DataSource getDataSource() {
		return dataSource;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public List<Category> getCategoriesBySectionId(int sectionId) {

		return jdbcTemplate.query(
				"select * from categories where section_id=?",
				new Object[] { sectionId }, new CategoryRowMapper());
	}

	private static final class CategoryRowMapper implements RowMapper<Category> {

		public Category mapRow(ResultSet resultSet, int rowNum)
				throws SQLException {
			Category category = new Category();
			category.setId(resultSet.getInt("id"));
			category.setName(resultSet.getString("name"));
			category.setSection_id(resultSet.getInt("section_id"));
			return category;
		}
	}

	@Override
	public boolean checkIfCategoryExists(String categoryName, int section_id) {
		try {
			jdbcTemplate
					.queryForObject(
							"select name from categories where name=? and section_id=?",
							new Object[] { categoryName, section_id },
							String.class);
			return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

	@Override
	public void addCategory(Category category) {
		jdbcTemplate
				.update("INSERT INTO categories(section_id,NAME,createdby,modifiedby,createddate,modifiedDate) VALUES(?,?,?,?,?,?)",
						new Object[] { category.getSection_id(),
								category.getName(), category.getCreatedBy(),
								category.getModifiedBy(),
								new Timestamp(new Date().getTime()),
								new Timestamp(new Date().getTime()) });

	}

}

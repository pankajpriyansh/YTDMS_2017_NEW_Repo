package com.yash.ytdms.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ytdms.dao.BatchDao;
import com.yash.ytdms.model.Batch;
import com.yash.ytdms.service.BatchService;

/**
 * 
 * @author goyal.ayush
 *
 */
@Service
public class BatchServiceImpl implements BatchService {

	@Autowired
	private BatchDao batchDao;

	public List<Batch> getAllBatches() {
		return batchDao.getAllBatches();
	}

	@Override
	public boolean checkIfBatchExists(String name) {
		return batchDao.checkIfBatchExists(name);
	}

	public void addBatch(Batch batch) {
		batchDao.addBatch(batch);
	}

	public int getTotalBatches() {
		return batchDao.getTotalBatches();
	}
}

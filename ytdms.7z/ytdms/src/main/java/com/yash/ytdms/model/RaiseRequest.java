package com.yash.ytdms.model;

import java.util.List;

import org.springframework.stereotype.Component;

/**
 * 
 * @author goyal.ayush
 *
 */
@Component
public class RaiseRequest {

	private int id;
	private int toTrainerId;
	private String reason;
	private List<Integer> documentsId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getToTrainerId() {
		return toTrainerId;
	}

	public void setToTrainerId(int toTrainerId) {
		this.toTrainerId = toTrainerId;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public List<Integer> getDocumentsId() {
		return documentsId;
	}

	public void setDocumentsId(List<Integer> documentsId) {
		this.documentsId = documentsId;
	}

}

package com.yash.ytdms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ytdms.model.Member;
import com.yash.ytdms.model.Section;
import com.yash.ytdms.service.SectionService;

/**
 * Used for the services that are related to Sections
 * 
 * @author goyal.ayush
 *
 */
@RestController
@RequestMapping("/sections")
@CrossOrigin(origins = "*")
public class SectionController {

	@Autowired
	private SectionService sectionService;
	
	@Autowired	
	private Member loggedInUser;


	/**
	 * 
	 * @return all sections from sections table
	 * @throws IOException
	 */
	@GetMapping(value = "/", produces = "application/json")
	public List<Section> getSections() throws IOException {
		List<Section> sections = sectionService.getAllSections();
		return sections;
	}

	/**
	 * 
	 * @return all the sections that are related to a specific batch
	 * @throws IOException
	 */
	@GetMapping(value = "/ByBatchId/{batchId}", produces = "application/json")
	public List<Section> getSectionsByBatchId(@PathVariable int batchId)
			throws IOException {
		List<Section> sections = sectionService.getSectionsByBatchId(batchId);
		return sections;
	}

	/**
	 * 
	 * @return all the sections that are related to a specific USER
	 * @throws IOException
	 */
	@GetMapping(value = "/ByUserId/{userId}", produces = "application/json")
	public List<Section> getSectionsByUserId(@PathVariable int userId)
			throws IOException {
		List<Section> sections = sectionService.getSectionsByUserId(userId);
		return sections;
	}

	/**
	 * percentage of course completion(percentage of how many documents readed
	 * by the user under a given section)
	 * 
	 * @param sectionId
	 * @param session
	 * @return
	 * @throws IOException
	 */
	@GetMapping(value = "/getCourseCompletionPercentage/{sectionId}", produces = "application/json")
	public int getCourseCompletionPercentage(@PathVariable int sectionId,
			HttpSession session, HttpServletRequest request) throws IOException {
		
		
		int userId = loggedInUser.getId();
		int batchId = loggedInUser.getBatchId();
		int courseCompletionPercentage = sectionService
				.getCourseCompletionPercentage(sectionId, userId, batchId);
		return courseCompletionPercentage;
	}

	/**
	 * Check if section with this name exists, Add section in DB and make
	 * section name folder under Documents name folder
	 * 
	 * @param section
	 * @param response
	 * @param session
	 * @param request
	 * @throws IOException
	 */
	@PostMapping("/")
	@ResponseBody
	public void addSection(@RequestBody Section section,
			HttpServletResponse response, HttpSession session,
			HttpServletRequest request) throws IOException {
		if (sectionService.checkIfSectionExists(section.getName())) {
			response.getWriter().append("sectionExists");
			return;
		}
		section.setCreatedBy(loggedInUser.getId());
		section.setModifiedBy(loggedInUser.getId());

		String workingDir = request.getServletContext().getRealPath("");
		sectionService.makeSectionNameFolder(workingDir, section.getName());
		sectionService.addSection(section);
	}

}

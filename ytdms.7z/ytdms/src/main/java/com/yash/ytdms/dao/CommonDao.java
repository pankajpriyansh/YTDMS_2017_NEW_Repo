package com.yash.ytdms.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.yash.ytdms.model.BatchMemberDocumentGraphData;
import com.yash.ytdms.model.SectionCategoryDocumentGraphData;

/**
 * 
 * @author goyal.ayush
 *
 */
@Repository
public interface CommonDao {
	List<SectionCategoryDocumentGraphData> getSectionCategoryDocumentGraphData(
			int batchId);

	List<BatchMemberDocumentGraphData> getBatchMemberGraphData();
}

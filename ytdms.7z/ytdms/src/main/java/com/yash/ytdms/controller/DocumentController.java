package com.yash.ytdms.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.yash.ytdms.model.Document;
import com.yash.ytdms.model.Member;
import com.yash.ytdms.service.DocumentService;

/**
 * Used for the services that are related to Documents
 * 
 * @author goyal.ayush
 *
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/documents")
public class DocumentController {

	@Autowired
	private DocumentService documentService;
	
	@Autowired	
	private Member loggedInUser;
	/**
	 * 
	 * @param sectionId
	 * @return the list of documents that are under a specific Section
	 * @throws IOException
	 */
	@GetMapping(value = "/bySectionId/{sectionId}")
	public List<Document> getDocumentsBySectionId(@PathVariable int sectionId)
			throws IOException {
		List<Document> documents = documentService
				.getDocumentsBySectionId(sectionId);
		return documents;
	}

	/**
	 * 
	 * @param sectionId
	 * @return the list of documents that are under a specific Section make by
	 *         the particular member
	 * @throws IOException
	 */
	@GetMapping(value = "/bySectionIdAndUserId/{sectionId}")
	public List<Document> getDocumentsBySectionIdAndUserId(
			@PathVariable int sectionId) throws IOException {
		List<Document> documents = documentService
				.getDocumentsBySectionIdAndUserId(sectionId,
						loggedInUser.getId());
		return documents;
	}

	/**
	 * 
	 * @param sectionId
	 *            , batchId
	 * @return the list of documents that are under a specific Section And with
	 *         the given batch id
	 * @throws IOException
	 */
	@GetMapping(value = "/bySectionIdAndBatchId/{sectionId}/{batchId}")
	public List<Document> getDocumentsBySectionIdAndBatchId(
			@PathVariable int sectionId, @PathVariable int batchId)
			throws IOException {
		List<Document> documents = documentService
				.getDocumentsBySectionIdAndBatchId(sectionId, batchId);
		return documents;
	}

	/**
	 * puts the entry of the user id and the given document id in
	 * members_document_junction table, with default value of count 0.
	 * 
	 * @param documentId
	 * @param session
	 * @param response
	 * @param model
	 * @throws IOException
	 */
	@PostMapping(value = "/markDocumentRead/{documentId}")
	public void markDocumentRead(@PathVariable int documentId,
			HttpSession session) throws IOException {
		int user_id = loggedInUser.getId();
		if (documentService.checkIfStatusAlreadyRead(documentId, user_id)) {
			// documentService.updateReadEntryOfDocument(documentId, user_id);
			return;
		} else {
			documentService.doEntryAsReadForThisDocument(documentId, user_id);
		}

	}

	/**
	 * used for updating COUNT of how many times user read this document
	 * 
	 * @param documentId
	 * @param session
	 * @param response
	 * @param model
	 * @throws IOException
	 */
	@PostMapping(value = "/updateDocumentReadCount/{documentId}")
	public void updateDocumentReadCount(@PathVariable int documentId,
			HttpSession session) throws IOException {
		try {
			int user_id = loggedInUser.getId();
			if (documentService.checkIfStatusAlreadyRead(documentId, user_id)) {
				documentService.updateReadEntryOfDocument(documentId, user_id);
				return;
			} else {
				// documentService.doEntryAsReadForThisDocument(documentId,
				// user_id);
			}
		} catch (Exception e) {
		}

	}

	/**
	 * 
	 * @param categoryId
	 * @param userId
	 * @return the list of documents that are under a specific Category And
	 *         created by the given userId
	 * @throws IOException
	 */
	@GetMapping(value = "/byCategoryIdAndUserId/{categoryId}/{userId}")
	public List<Document> getDocumentsByCategoryIdAndUserId(
			@PathVariable int categoryId, @PathVariable int userId)
			throws IOException {
		List<Document> documents = documentService
				.getDocumentsByCategoryIdAndUserId(categoryId, userId);
		return documents;
	}

	/**
	 * 
	 * @param session
	 * @return All the documents that are shown to the logged in user
	 * @throws IOException
	 */
	@GetMapping(value = "/getAllActiveDocuments")
	public List<Document> getAllActiveDocuments(HttpSession session)
			throws IOException {

		List<Document> documents = documentService.getAllActiveDocuments(
				loggedInUser.getBatchId(), loggedInUser.getId());
		return documents;
	}

	/**
	 * 
	 * @param userId
	 * @param documentId
	 * @return 1. READ - if user clicks on CompleteAndContinue 2. UNREAD - if
	 *         user haven't clicked on that document 3. PENDING - if user
	 *         clicked on that document but not clicked on CompleteAndContinue
	 * @throws IOException
	 */
	@GetMapping(value = "/getDocumentCompletionStatus/{userId}/{documentId}")
	public Map<String, String> getDocumentCompletionStatus(
			@PathVariable int userId, @PathVariable int documentId)
			throws IOException {
		String status = documentService.getDocumentCompletionStatus(userId,
				documentId);
		Map<String, String> map = new HashMap<String, String>();
		map.put("status", status);
		return map;
	}

	/**
	 * 
	 * @param batchId
	 * @param session
	 * @return list of documents based on batch Id , that are created by the
	 *         logged in trainer
	 * @throws IOException
	 */
	@GetMapping(value = "/getDocumentsByBatchId/{batchId}")
	public List<Document> getDocumentsByBatchId(@PathVariable int batchId,
			HttpSession session) throws IOException {

		List<Document> documents = documentService
				.getDocumentsByBatchIdAndMemberId(batchId, loggedInUser.getId());
		return documents;
	}

	/**
	 * 
	 * @param batchId
	 * @param documentId
	 * @param response
	 * @param modelMap
	 * @return list of data that contains read status of documents , along with
	 *         first seen, last seen, count etc..
	 * @throws IOException
	 */
	@GetMapping(value = "/checkDocumentReadStatus/{batchId}/{documentId}")
	public List checkDocumentReadStatus(@PathVariable int batchId,
			@PathVariable int documentId) throws IOException {
		List list = documentService.getDocumentReadStautsList(batchId,
				documentId);
		return list;

	}

	/**
	 * shifting the documents , Batch wise
	 * 
	 * @param fromBatchId
	 * @param toBatchId
	 * @param session
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(value = "/shiftDocumentsByBatch/{fromBatchId}/{toBatchId}")
	public void shiftDocumentsByBatch(@PathVariable int fromBatchId,
			@PathVariable int toBatchId, HttpSession session)
			throws IOException {

		documentService.shiftDocumentsByBatch(fromBatchId, toBatchId,
				loggedInUser.getId());
	}

	/**
	 * 
	 * @param fromBatchId
	 * @param toBatchId
	 * @param sectionId
	 * @param session
	 * @throws IOException
	 */
	@RequestMapping(value = "/shiftDocumentsBySection/{fromBatchId}/{toBatchId}/{sectionId}")
	public void shiftDocumentsBySection(@PathVariable int fromBatchId,
			@PathVariable int toBatchId, @PathVariable int sectionId,
			HttpSession session) throws IOException {
		documentService.shiftDocumentsBySection(fromBatchId, toBatchId,
				sectionId, loggedInUser.getId());
	}

	/**
	 * 
	 * @param document
	 * @param file
	 * @param sectionName
	 * @param categoryName
	 * @param session
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@PostMapping(value = "/saveDocument")
	@ResponseBody
	public void saveDocument(@ModelAttribute Document document,
			@RequestParam("fileToUpload") MultipartFile file,
			@RequestParam("sectionName") String sectionName,
			@RequestParam("categoryName") String categoryName,
			@RequestParam("batch_id") String batch_id,
			@RequestParam("categoryId") String categoryId,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		document.setBatchId(Integer.parseInt(batch_id));
		document.setCategory_id(Integer.parseInt(categoryId));

		if (documentService.documentNameExistsUnderThisBatch(
				document.getBatchId(), document.getName())) {
			response.getWriter().append("alreadyExists");
			return;
		}
		document.setFilePath(sectionName + "/" + categoryName + "/"
				+ file.getOriginalFilename());
		document.setUser_id(loggedInUser.getId());
		String workingDir = request.getServletContext().getRealPath("");
		documentService.uploadFile(file, workingDir, document.getFilePath());
		documentService.addDocument(document);
	}

	/**
	 * 
	 * @param documentId
	 * @throws IOException
	 */
	@PostMapping(value = "/deleteDocument/{documentId}")
	public void deleteDocument(@PathVariable int documentId) throws IOException {
		documentService.deleteDocumentById(documentId);
	}

	/**
	 * 
	 * @param documentId
	 * @param response
	 * @param model
	 * @throws IOException
	 */
	@GetMapping(value = "/byId/{documentId}")
	public Document getDocumentById(@PathVariable int documentId,
			HttpServletResponse response, Model model) throws IOException {
		Document document = documentService.getDocumentById(documentId);
		return document;
	}

	/**
	 * provide id,name,description,batchID in document object
	 * 
	 * @param documentId
	 * @param description
	 * @param name
	 * @param response
	 * @param model
	 * @throws IOException
	 */
	@PostMapping(value = "/editDocument")
	@ResponseBody
	public void editDocument(@RequestBody Document document,
			HttpServletResponse response, Model model) throws IOException {
		if (documentService.documentNameExistsUnderThisBatch(
				document.getBatchId(), document.getName())) {
			response.getWriter().append("alreadyExists");
			return;
		}
		documentService.updateDocument(document.getId(), document.getName(),
				document.getDescription());
	}

	/**
	 * 
	 * documentid - id of document , status - show/hide
	 * 
	 * @param documentId
	 * @param status
	 * @param response
	 * @throws IOException
	 */
	@PostMapping(value = "/onStatusChangeOfShowHide/{documentId}/{status}")
	public void onStatusChangeEventHandler(@PathVariable int documentId,
			@PathVariable String status, HttpServletResponse response)
			throws IOException {
		if (status.equalsIgnoreCase("show"))
			documentService.changeStatusOfDocumentByDocumentId(documentId, 1);
		else
			documentService.changeStatusOfDocumentByDocumentId(documentId, 2);
	}

	/**
	 * for specific member, its entry inserted in database, and after 2 days ,
	 * this entry will be automatically deleted
	 * 
	 * @param documentId
	 * @param status
	 * @param memberId
	 * @param response
	 * @throws IOException
	 */
	@PostMapping(value = "/onStatusChangeOfShowHideForSpecificMember/{documentId}/{status}/{memberId}")
	public void onStatusChangeOfShowHideForSpecificMember(
			@PathVariable int documentId, @PathVariable String status,
			@PathVariable int memberId, HttpServletResponse response)
			throws IOException {
		documentService.changeStatusOfDocumentByDocumentIdForSpecificMember(
				documentId, memberId);
	}

}

package com.yash.ytdms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.yash.ytdms.model.BatchMemberDocumentGraphData;
import com.yash.ytdms.model.SectionCategoryDocumentGraphData;

/**
 * 
 * @author goyal.ayush
 *
 */
@Service
public interface CommonService {
	List<SectionCategoryDocumentGraphData> getSectionCategoryDocumentGraphData(
			int batchId);

	List<BatchMemberDocumentGraphData> getBatchMemberGraphData();
}

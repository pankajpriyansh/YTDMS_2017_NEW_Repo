package com.yash.ytdms.model;

import org.springframework.stereotype.Component;

@Component
public class BatchMemberDocumentGraphData {

	private String batchName;
	private int totalMembers;
	private int totalDocuments;

	public String getBatchName() {
		return batchName;
	}

	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}

	public int getTotalMembers() {
		return totalMembers;
	}

	public void setTotalMembers(int totalMembers) {
		this.totalMembers = totalMembers;
	}

	public int getTotalDocuments() {
		return totalDocuments;
	}

	public void setTotalDocuments(int totalDocuments) {
		this.totalDocuments = totalDocuments;
	}

}

package com.yash.ytdms.model;

import org.springframework.stereotype.Component;

@Component
public class DocumentsRequest {

	private int id;
	private int fromUserId;
	private int toUserId;
	private int isActive;
	private String reason;
	private String rejectedReason;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getFromUserId() {
		return fromUserId;
	}

	public void setFromUserId(int fromUserId) {
		this.fromUserId = fromUserId;
	}

	public int getToUserId() {
		return toUserId;
	}

	public void setToUserId(int toUserId) {
		this.toUserId = toUserId;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getRejectedReason() {
		return rejectedReason;
	}

	public void setRejectedReason(String rejectedReason) {
		this.rejectedReason = rejectedReason;
	}

	@Override
	public String toString() {
		return "DocumentsRequest [id=" + id + ", fromUserId=" + fromUserId
				+ ", toUserId=" + toUserId + ", isActive=" + isActive
				+ ", reason=" + reason + ", rejectedReason=" + rejectedReason
				+ "]";
	}

}

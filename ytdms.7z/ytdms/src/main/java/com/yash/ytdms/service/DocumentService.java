package com.yash.ytdms.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.yash.ytdms.model.Document;
import com.yash.ytdms.model.DocumentsRequest;

/**
 * DocumentService provides all the services and functionalities related to
 * Document. This is the design, implemented by any specific implementation
 * provider . It contains all the services related to business logics .
 * 
 * @author goyal.ayush
 *
 *
 */
@Service
public interface DocumentService {

	boolean checkIfStatusAlreadyRead(int documentId, int user_id);

	void doEntryAsReadForThisDocument(int documentId, int user_id);

	void updateReadEntryOfDocument(int documentId, int user_id);

	List<Document> getDocumentsBySectionId(int sectionId);

	List<Document> getDocumentsBySectionIdAndBatchId(int sectionId, int batchId);

	List<Document> getDocumentsByCategoryIdAndUserId(int categoryId, int userId);

	void saveRequestForDocument(int id, int toTrainerId,
			List<Integer> documentsId, String reason);

	void hideDocumentForSpecificMember();

	List getRequestedDocumentsData(int id);

	List<Integer> getDocumentsIdListFromDocumentsRequestId(int requestId);

	void approveRequestForDocument(int requestId, List<Integer> documentsId,
			int memberId);

	void saveReasonForRejectionOfRequest(int id, String rejectedReason);

	List<Document> getAllActiveDocuments(int batchId, int id);

	List getRequestedDocumentReportsBasicData(int id);

	List getRequestedDocumentReportsAdvanceData(int fromUserId, int toUserId);

	String getDocumentCompletionStatus(int userId, int documentId);

	List<Document> getDocumentsByBatchIdAndMemberId(int batchId, int id);

	List getDocumentReadStautsList(int batchId, int documentId);

	void shiftDocumentsByBatch(int fromBatchId, int toBatchId, int id);

	void shiftDocumentsBySection(int fromBatchId, int toBatchId, int sectionId,
			int id);

	boolean documentNameExistsUnderThisBatch(int batchId, String name);

	void uploadFile(MultipartFile file, String workingDir, String filePath);

	void addDocument(Document document);

	void deleteDocumentById(int documentId);

	Document getDocumentById(int documentId);

	void updateDocument(int id, String name, String description);

	void changeStatusOfDocumentByDocumentId(int documentId, int i);

	void changeStatusOfDocumentByDocumentIdForSpecificMember(int documentId,
			int memberId);

	List<Document> getDocumentsBySectionIdAndUserId(int sectionId, int userId);

}

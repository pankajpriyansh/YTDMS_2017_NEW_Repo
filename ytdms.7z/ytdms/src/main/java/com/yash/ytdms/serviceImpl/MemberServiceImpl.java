package com.yash.ytdms.serviceImpl;

import java.util.Hashtable;
import java.util.List;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.util.BasicInitializationsForLDAP;
import com.yash.ytdms.dao.MemberDao;
import com.yash.ytdms.model.Member;
import com.yash.ytdms.model.PreAuthenticateMember;
import com.yash.ytdms.service.MemberService;

/**
 * 
 * @author goyal.ayush
 *
 */
@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberDao memberDao;

	// private SearchResult searchResult;

	public boolean checkForAuthentication(String email, String password) {
		// return memberDao.checkForAuthentication(email, password);
		// LDAP CODE
		String accountToLookUp;
		Hashtable<String, Object> environment = initializeHashTableEnvironmentVariables(
				email, password);
		accountToLookUp = "sAMAccountName="
				+ email.substring(0, email.indexOf("@"));
		InitialDirContext ctx = null;
		try {
			ctx = new InitialDirContext(environment);
			SearchControls searchControls = new SearchControls();
			searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			NamingEnumeration<SearchResult> results = ctx.search(
					BasicInitializationsForLDAP.LDADP_SEARCH_BASE,
					accountToLookUp, searchControls);
			if (results.hasMoreElements()) {
				// searchResult = results.nextElement();
				return true;
			}
			ctx.close();
		} catch (NamingException e) {
			e.printStackTrace();
		}
		return false;

	}

	public Hashtable<String, Object> initializeHashTableEnvironmentVariables(
			String email, String password) {
		Hashtable<String, Object> environment = new Hashtable<>();
		environment.put(Context.SECURITY_AUTHENTICATION,
				BasicInitializationsForLDAP.LDAP_SECURITY_AUTHENTICATION);
		environment.put(Context.INITIAL_CONTEXT_FACTORY,
				BasicInitializationsForLDAP.LDAP_INITIAL_CONTEXT_FACTORY);
		environment.put(Context.PROVIDER_URL,
				BasicInitializationsForLDAP.LDAP_PROVIDER_URL);
		environment.put(Context.SECURITY_PRINCIPAL, email);
		environment.put(Context.SECURITY_CREDENTIALS, password);

		/**
		 * objectSID --> When a new object is created in Directory, Domain
		 * Controller assigns a unique value used to identify the object as a
		 * security principal. This value is unique inside the domain.
		 * 
		 * 'java.naming.ldap.attributes.binary' attribute informs the Context
		 * that the 'objectSid' attribute should be fetched as byte[] (and not
		 * as string) - this is crucial. In order to get the objectSID properly
		 * , we need to add it to the list of binary attributes.
		 */
		environment.put("java.naming.ldap.attributes.binary", "objectSID");
		return environment;
	}

	public Member getMemberByEmail(String email) {
		return memberDao.getMemberByEmail(email);
	}

	public void addMember(Member member) {
		memberDao.addMember(member);
	}

	public boolean checkIfEmailExists(String email) {
		return memberDao.checkIfEmailExists(email);
	}

	public List<Member> getAllTrainers() {
		return memberDao.getAllTrainers();
	}

	@Override
	public Member getAuthenticateMemberFromPreAuthenticateMember(
			PreAuthenticateMember member) {
		Member authenticateMember = new Member();
		authenticateMember.setBatchId(member.getBatchId());
		authenticateMember.setFirstname(member.getFirstname());
		authenticateMember.setLastname(member.getLastname());
		authenticateMember.setEmail(member.getEmail());
		authenticateMember.setContact(member.getContact());
		return authenticateMember;
	}

	@Override
	public List<Member> getMembersByBatchId(int batchId) {
		return memberDao.getMembersByBatchId(batchId);
	}

}

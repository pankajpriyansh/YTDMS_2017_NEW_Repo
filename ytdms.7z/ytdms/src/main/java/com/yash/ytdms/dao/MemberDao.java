package com.yash.ytdms.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.yash.ytdms.model.Member;

/**
 * MemberDao will hold all the common CRUD tasks related to member. This is the
 * design, implementation will be provided by the specific type of
 * implementation
 * 
 * @author goyal.ayush
 *
 */
@Repository
public interface MemberDao {

	/**
	 * addMember method will add the provided member in the data base
	 * 
	 * @param member
	 */
	public void addMember(Member member);

	public Member getMemberByEmail(String email);

	public boolean checkIfEmailExists(String email);

	public List<Member> getAllTrainers();

	public List<Member> getMembersByBatchId(int batchId);

}

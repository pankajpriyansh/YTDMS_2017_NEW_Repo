package com.yash.ytdms.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.yash.ytdms.model.Category;

/**
 * CategoryDao will hold all the common CRUD tasks related to Category. This is
 * the design, implementation will be provided by the specific type of
 * implementation
 * 
 * @author goyal.ayush
 *
 */
@Repository
public interface CategoryDao {

	List<Category> getCategoriesBySectionId(int sectionId);

	boolean checkIfCategoryExists(String name, int section_id);

	void addCategory(Category category);

}

package com.yash.ytdms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.yash.ytdms.model.Role;

/**
 * 
 * @author goyal.ayush
 *
 */
@Service
public interface RoleService {

	List<Role> getAllRoles();

	Role getRoleById(int id);

}

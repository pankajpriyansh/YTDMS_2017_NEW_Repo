package com.yash.ytdms.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ytdms.model.Role;
import com.yash.ytdms.service.RoleService;

/**
 * Used for the services that are related to Roles
 * 
 * @author goyal.ayush
 *
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/roles")
public class RoleController {

	@Autowired
	private RoleService roleService;

	/**
	 * 
	 * @return All Role model object available in database
	 * @throws IOException
	 */
	@GetMapping(value = "/")
	public List<Role> getRoles() throws IOException {
		List<Role> roles = roleService.getAllRoles();
		return roles;
	}

	/**
	 * 
	 * @param id
	 * @return the Role model object corresponding to the given Id
	 * @throws IOException
	 */
	@GetMapping(value = "/{id}")
	public Role getRolesByRoleId(@PathVariable int id) throws IOException {
		Role role = roleService.getRoleById(id);
		return role;
	}

}

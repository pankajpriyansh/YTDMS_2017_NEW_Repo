package com.yash.ytdms.daoJdbcImpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.yash.ytdms.dao.CommonDao;
import com.yash.ytdms.model.BatchMemberDocumentGraphData;
import com.yash.ytdms.model.Section;
import com.yash.ytdms.model.SectionCategoryDocumentGraphData;

/**
 * 
 * @author goyal.ayush
 *
 */
@Repository
public class CommonDaoImpl implements CommonDao {
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;

	public DataSource getDataSource() {
		return dataSource;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<SectionCategoryDocumentGraphData> getSectionCategoryDocumentGraphData(
			int batchId) {

		List<Section> sections = jdbcTemplate.query("select * from sections",
				new SectionRowMapper());
		List<SectionCategoryDocumentGraphData> listOfData = new ArrayList<SectionCategoryDocumentGraphData>();
		List listOfSectionAndTotalDocuments = jdbcTemplate
				.query("SELECT sec.name AS sectionName,COUNT(*) AS totalDocuments FROM sections sec , categories cat, documents doc WHERE doc.category_id=cat.`id` AND cat.`section_id`=sec.id AND doc.batch_id=?  GROUP BY sec.id;",
						new Object[] { batchId },
						new SectionAndTotalDocumentsRowMapper());

		List listOfSectionAndTotalCategories = jdbcTemplate
				.query("SELECT sec.name AS sectionName,COUNT(*) AS totalCategories FROM sections sec,categories cat WHERE sec.id=cat.section_id GROUP BY sec.name;",
						new SectionAndTotalCategoriesRowMapper());
		sections.forEach((i) -> {
			SectionCategoryDocumentGraphData list = new SectionCategoryDocumentGraphData();
			list.setSectionName(i.getName());
			list.setTotalCategoies(getTotalCategoriesUnderThisSection(
					listOfSectionAndTotalCategories, i.getName()));
			list.setTotalDocuments(getTotalDocumentsUnderThisSection(
					listOfSectionAndTotalDocuments, i.getName()));
			listOfData.add(list);
		});
		System.out.println(listOfData);
		return listOfData;

	}

	private int getTotalDocumentsUnderThisSection(
			List listOfSectionAndTotalDocuments, String sectionName) {
		for (Object object : listOfSectionAndTotalDocuments) {
			List list = (List) object;
			if (((String) list.get(1)).equals(sectionName)) {
				return (int) list.get(0);
			}

		}
		return 0;
	}

	private int getTotalCategoriesUnderThisSection(
			List listOfSectionAndTotalCategories, String sectionName) {
		for (Object object : listOfSectionAndTotalCategories) {
			List list = (List) object;
			if (((String) list.get(1)).equals(sectionName)) {
				return (int) list.get(0);
			}
		}
		return 0;
	}

	private static final class SectionAndTotalDocumentsRowMapper implements
			RowMapper<List> {

		public List mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			List list = new ArrayList();
			list.add(resultSet.getInt("totalDocuments"));
			list.add(resultSet.getString("sectionName"));
			return list;
		}
	}

	private static final class SectionAndTotalCategoriesRowMapper implements
			RowMapper<List> {

		public List mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			List list = new ArrayList();
			list.add(resultSet.getInt("totalCategories"));
			list.add(resultSet.getString("sectionName"));
			return list;
		}
	}

	private static final class SectionRowMapper implements RowMapper<Section> {

		public Section mapRow(ResultSet resultSet, int rowNum)
				throws SQLException {
			Section section = new Section();
			section.setId(resultSet.getInt("id"));
			section.setName(resultSet.getString("name"));
			return section;
		}
	}

	@Override
	public List<BatchMemberDocumentGraphData> getBatchMemberGraphData() {
		return jdbcTemplate
				.query("SELECT bat.name AS batchName,(SELECT COUNT(*) FROM members mem WHERE mem.`batch_id`=bat.id GROUP BY mem.`batch_id`) AS totalMembers, IFNULL((SELECT COUNT(*) FROM documents doc WHERE doc.`batch_id`=bat.id GROUP BY doc.`batch_id` ),0) AS totalDocuments FROM batches bat;",
						new BatchAndTotalMemberRowMapper());
	}

	private static final class BatchAndTotalMemberRowMapper implements
			RowMapper<BatchMemberDocumentGraphData> {

		public BatchMemberDocumentGraphData mapRow(ResultSet resultSet,
				int rowNum) throws SQLException {
			BatchMemberDocumentGraphData list = new BatchMemberDocumentGraphData();
			list.setTotalMembers(resultSet.getInt("totalMembers"));
			list.setBatchName(resultSet.getString("batchName"));
			list.setTotalDocuments(resultSet.getInt("totalDocuments"));
			return list;
		}
	}

}

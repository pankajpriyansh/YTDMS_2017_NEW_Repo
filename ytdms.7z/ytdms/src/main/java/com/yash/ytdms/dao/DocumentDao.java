package com.yash.ytdms.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.yash.ytdms.model.Document;
import com.yash.ytdms.model.DocumentsRequest;

/**
 * DocumentDao will hold all the common CRUD tasks related to Document. This is
 * the design, implementation will be provided by the specific type of
 * implementation
 * 
 * @author goyal.ayush
 *
 */
@Repository
public interface DocumentDao {

	boolean checkIfStatusAlreadyRead(int documentId, int user_id);

	void doEntryAsReadForThisDocument(int documentId, int user_id);

	void updateReadEntryOfDocument(int documentId, int user_id);

	List<Document> getDocumentsBySectionId(int sectionId);

	List<Document> getDocumentsBySectionIdAndBatchId(int sectionId, int batchId);

	List<Document> getDocumentsByCategoryIdAndUserId(int categoryId, int userId);

	void saveRequestForDocument(int fromUserId, int toUserId,
			List<Integer> documentsId, String reason);

	void hideDocumentForSpecificMember();

	List getRequestedDocumentsData(int memberId);

	List<Integer> getDocumentsIdListFromDocumentsRequestId(int requestId);

	void approveRequestForDocument(int requestId, List<Integer> documentsId,
			int memberId);

	void saveReasonForRejectionOfRequest(int id, String rejectedReason);

	List<Document> getAllActiveDocuments(int batchId, int memberId);

	List getRequestedDocumentReportsBasicData(int id);

	List getRequestedDocumentReportsAdvanceData(int fromUserId, int toUserId);

	String getDocumentCompletionStatus(int userId, int documentId);

	List<Document> getDocumentsByBatchIdAndMemberId(int batchId, int userId);

	List getDocumentReadStautsList(int batchId, int documentId);

	void shiftDocumentsByBatch(int fromBatchId, int toBatchId, int userId);

	void shiftDocumentsByBatch(int fromBatchId, int toBatchId, int sectionId,
			int userId);

	boolean documentNameExistsUnderThisBatch(int batchId, String name);

	void addDocument(Document document);

	void deleteDocumentById(int documentId);

	Document getDocumentById(int documentId);

	void updateDocument(int id, String name, String description);

	void changeStatusOfDocumentByDocumentId(int documentId, int status);

	void changeStatusOfDocumentByDocumentIdForSpecificMember(int documentId,
			int memberId);

	List<Document> getDocumentsBySectionIdAndUserId(int sectionId, int userId);

}

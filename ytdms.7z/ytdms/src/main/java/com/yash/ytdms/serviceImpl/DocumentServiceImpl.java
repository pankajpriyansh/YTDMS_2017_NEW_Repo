package com.yash.ytdms.serviceImpl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.yash.ytdms.dao.DocumentDao;
import com.yash.ytdms.model.Document;
import com.yash.ytdms.model.DocumentsRequest;
import com.yash.ytdms.service.CategoryService;
import com.yash.ytdms.service.DocumentService;

/**
 * DocumentServiceImpl is the implementation of all the services and
 * functionalities related to Document. It contains all the services related to
 * business logics. Whenever there is a need of database , it can have a call to
 * DAO , to fulfill the need.
 * 
 * @author goyal.ayush
 *
 */
@Service
public class DocumentServiceImpl implements DocumentService {

	@Autowired
	private DocumentDao documentDao;

	@Autowired
	private CategoryService categoryService;

	public boolean checkIfStatusAlreadyRead(int documentId, int user_id) {
		return documentDao.checkIfStatusAlreadyRead(documentId, user_id);
	}

	public void doEntryAsReadForThisDocument(int documentId, int user_id) {
		documentDao.doEntryAsReadForThisDocument(documentId, user_id);
	}

	public void updateReadEntryOfDocument(int documentId, int user_id) {
		documentDao.updateReadEntryOfDocument(documentId, user_id);
	}

	@Override
	public List<Document> getDocumentsBySectionId(int sectionId) {

		return documentDao.getDocumentsBySectionId(sectionId);
	}

	@Override
	public List<Document> getDocumentsBySectionIdAndBatchId(int sectionId,
			int batchId) {
		return documentDao
				.getDocumentsBySectionIdAndBatchId(sectionId, batchId);
	}

	@Override
	public List<Document> getDocumentsByCategoryIdAndUserId(int categoryId,
			int userId) {
		return documentDao
				.getDocumentsByCategoryIdAndUserId(categoryId, userId);
	}

	@Override
	public void saveRequestForDocument(int fromUserId, int toUserId,
			List<Integer> documentsId, String reason) {
		documentDao.saveRequestForDocument(fromUserId, toUserId, documentsId,
				reason);

	}

	@Override
	public void hideDocumentForSpecificMember() {
		documentDao.hideDocumentForSpecificMember();

	}

	@Override
	public List getRequestedDocumentsData(int memberId) {
		return documentDao.getRequestedDocumentsData(memberId);
	}

	@Override
	public List<Integer> getDocumentsIdListFromDocumentsRequestId(int requestId) {
		return documentDao.getDocumentsIdListFromDocumentsRequestId(requestId);
	}

	@Override
	public void approveRequestForDocument(int requestId,
			List<Integer> documentsId, int memberId) {
		documentDao.approveRequestForDocument(requestId, documentsId, memberId);
	}

	@Override
	public void saveReasonForRejectionOfRequest(int id, String rejectedReason) {
		documentDao.saveReasonForRejectionOfRequest(id, rejectedReason);

	}

	@Override
	public List<Document> getAllActiveDocuments(int batchId, int id) {
		return documentDao.getAllActiveDocuments(batchId, id);
	}

	@Override
	public List getRequestedDocumentReportsBasicData(int id) {
		return documentDao.getRequestedDocumentReportsBasicData(id);
	}

	@Override
	public List getRequestedDocumentReportsAdvanceData(int fromUserId,
			int toUserId) {
		return documentDao.getRequestedDocumentReportsAdvanceData(fromUserId,
				toUserId);
	}

	@Override
	public String getDocumentCompletionStatus(int userId, int documentId) {
		return documentDao.getDocumentCompletionStatus(userId, documentId);
	}

	@Override
	public List<Document> getDocumentsByBatchIdAndMemberId(int batchId,
			int userId) {
		return documentDao.getDocumentsByBatchIdAndMemberId(batchId, userId);
	}

	@Override
	public List getDocumentReadStautsList(int batchId, int documentId) {
		return documentDao.getDocumentReadStautsList(batchId, documentId);
	}

	@Override
	public void shiftDocumentsByBatch(int fromBatchId, int toBatchId, int userId) {
		documentDao.shiftDocumentsByBatch(fromBatchId, toBatchId, userId);
	}

	@Override
	public void shiftDocumentsBySection(int fromBatchId, int toBatchId,
			int sectionId, int userId) {
		documentDao.shiftDocumentsByBatch(fromBatchId, toBatchId, sectionId,
				userId);

	}

	@Override
	public boolean documentNameExistsUnderThisBatch(int batchId, String name) {
		return documentDao.documentNameExistsUnderThisBatch(batchId, name);
	}

	@Override
	public void uploadFile(MultipartFile file, String workingDir,
			String filePath) {

		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				File uploadedDocument = new File(workingDir + File.separator
						+ ".." + File.separator + "ytdms-cli" + File.separator
						+ "assets" + File.separator + "Documents"
						+ File.separator + filePath);
				BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(
						new FileOutputStream(uploadedDocument));
				bufferedOutputStream.write(bytes);
				bufferedOutputStream.close();
			} catch (Exception e) {
				System.out.println("file not upload " + e.getMessage());
			}
		}

	}

	@Override
	public void addDocument(Document document) {
		documentDao.addDocument(document);
	}

	@Override
	public void deleteDocumentById(int documentId) {
		documentDao.deleteDocumentById(documentId);
	}

	@Override
	public Document getDocumentById(int documentId) {
		return documentDao.getDocumentById(documentId);
	}

	@Override
	public void updateDocument(int id, String name, String description) {
		documentDao.updateDocument(id, name, description);

	}

	@Override
	public void changeStatusOfDocumentByDocumentId(int documentId, int status) {
		documentDao.changeStatusOfDocumentByDocumentId(documentId, status);
	}

	@Override
	public void changeStatusOfDocumentByDocumentIdForSpecificMember(
			int documentId, int memberId) {
		documentDao.changeStatusOfDocumentByDocumentIdForSpecificMember(
				documentId, memberId);
	}

	@Override
	public List<Document> getDocumentsBySectionIdAndUserId(int sectionId,
			int userId) {
		return documentDao.getDocumentsBySectionIdAndUserId(sectionId, userId);
	}
}

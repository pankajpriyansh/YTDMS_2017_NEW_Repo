package com.yash.ytdms.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.yash.ytdms.model.Section;

/**
 * SectionDao will hold all the common CRUD tasks related to Section. This is
 * the design, implementation will be provided by the specific type of
 * implementation
 * 
 * @author goyal.ayush
 *
 */
@Repository
public interface SectionDao {
	/**
	 * returns all sections, created by the specific user , based on user id
	 * 
	 * @param userId
	 * 
	 * @return
	 */
	List<Section> getAllSections();

	List<Section> getSectionsByBatchId(int batchId);

	int getCourseCompletionPercentage(int sectionId, int userId, int batchId);

	List<Section> getSectionsByUserId(int userId);

	boolean checkIfSectionExists(String name);

	void addSection(Section section);

	String getSectionNameBySectionId(int sectionId);

}

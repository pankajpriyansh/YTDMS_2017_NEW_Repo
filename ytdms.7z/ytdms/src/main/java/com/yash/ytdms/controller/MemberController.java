package com.yash.ytdms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ytdms.model.Member;
import com.yash.ytdms.model.PreAuthenticateMember;
import com.yash.ytdms.service.MemberService;

/**
 * Used for the services that are related to Members , such as Login , Logout ,
 * Registration etc.
 * 
 * @author goyal.ayush
 *
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/members")
public class MemberController {
	@Autowired
	private MemberService memberService;

	@Autowired
	private Member loggedInUser;

	/**
	 * for registering a member in YTDMS. After saving the member in DB, a
	 * request goes to Admin for approval.
	 * 
	 * @param member
	 * @param response
	 * @throws IOException
	 */
	@PostMapping(value = "/")
	@ResponseBody
	public void saveMember(@RequestBody PreAuthenticateMember member,
			HttpServletResponse response) throws IOException {
		System.out.println(member);
		if (memberService.checkIfEmailExists(member.getEmail())) {
			response.getWriter().append("emailExists");
		} else if (!memberService.checkForAuthentication(member.getEmail(),
				member.getPassword())) {
			response.getWriter().append("NotAuthenticateFromLDAP");
		} else {
			Member authenticateMember = memberService
					.getAuthenticateMemberFromPreAuthenticateMember(member);
			authenticateMember.setBatchId(member.getBatchId());
			authenticateMember.setFirstname(member.getFirstname());
			authenticateMember.setLastname(member.getLastname());
			authenticateMember.setEmail(member.getEmail());
			authenticateMember.setContact(member.getContact());
			System.out.println(authenticateMember);
			memberService.addMember(authenticateMember);
			response.getWriter().append("MemberCreated");
		}

	}

	/**
	 * Used for authenticating a user to login in YTDMS.
	 * 
	 * @param member
	 * @param session
	 * @param response
	 * @return Member if user is authenticated , else null
	 * @throws IOException
	 */
	@RequestMapping(value = "/authenticate", produces = "application/json")
	@ResponseBody
	public Member authenticate(@RequestBody PreAuthenticateMember member,
			HttpSession session, HttpServletResponse response,
			HttpServletRequest request) throws IOException {

		if (memberService.checkForAuthentication(member.getEmail(),
				member.getPassword())
				|| (member.getEmail().equals("ytdms.manager@yash.com") && member
						.getPassword().equals("Manid@23646"))) {
			try {
				Member authenticatedMember = memberService
						.getMemberByEmail(member.getEmail());
				if (authenticatedMember.getIsActive() == 2
						|| authenticatedMember.getIsRegistered() == 2)
					return new Member();
				else {
					loggedInUser.setId(authenticatedMember.getId());
					loggedInUser.setFirstname(authenticatedMember
							.getFirstname());
					loggedInUser.setLastname(authenticatedMember.getLastname());
					loggedInUser.setEmail(authenticatedMember.getEmail());
					loggedInUser.setBatchId(authenticatedMember.getBatchId());
					loggedInUser.setIsActive(authenticatedMember.getIsActive());
					loggedInUser.setRole(authenticatedMember.getRole());
					loggedInUser.setIsRegistered(authenticatedMember
							.getIsRegistered());

					// session.setAttribute("loggedInUser",
					// authenticatedMember);

				}
				return authenticatedMember;
			} catch (Exception e) {

			}
		} else {
		}
		return new Member();
	}

	/**
	 * invalidate session on logout
	 * 
	 * @param session
	 */
	@RequestMapping("/logout")
	public void logout(HttpSession session) {
		this.loggedInUser = null;
	}

	@GetMapping("/getAllTrainers")
	public List<Member> getAllTrainers() {
		List<Member> members = new ArrayList<Member>();
		try {
			members = memberService.getAllTrainers();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return members;
	}

	@GetMapping(value = "/getListOfMembersByBatchId/{batchId}")
	public List<Member> getListOfMembersByBatchId(@PathVariable int batchId,
			HttpServletResponse response, Model model) throws IOException {
		return memberService.getMembersByBatchId(batchId);
	}

}

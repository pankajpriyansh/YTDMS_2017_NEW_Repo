package com.yash.ytdms.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ytdms.model.Member;
import com.yash.ytdms.model.RaiseRequest;
import com.yash.ytdms.service.DocumentService;
import com.yash.ytdms.service.MemberService;

/**
 * Used for the services that are ONLY related to Trainee
 * 
 * @author goyal.ayush
 *
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/trainee")
public class TraineeController {

	@Autowired
	private DocumentService documentService;

	@Autowired
	private MemberService memberService;
	
	@Autowired	
	private Member loggedInUser;

	

	/**
	 * trainee raise request for viewing documents once again. after approval
	 * from the trainer the documents will be visible to trainee only for 2
	 * days. If rejected, the trainer need to provide a reason for rejection.
	 * 
	 * @param raiseRequest
	 * @param response
	 * @param session
	 * @throws IOException
	 */
	@PostMapping(value = "/raiseRequest")
	@ResponseBody
	public void raiseRequest(@RequestBody RaiseRequest raiseRequest,
			HttpServletResponse response, HttpSession session)
			throws IOException {
		documentService.saveRequestForDocument(
				loggedInUser.getId(),
				raiseRequest.getToTrainerId(), raiseRequest.getDocumentsId(),
				raiseRequest.getReason());
	}

}

package com.yash.ytdms.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ytdms.dao.RoleDao;
import com.yash.ytdms.model.Role;
import com.yash.ytdms.service.RoleService;

/**
 * 
 * @author goyal.ayush
 *
 */
@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleDao roleDao;

	@Override
	public List<Role> getAllRoles() {
		return roleDao.getAllRoles();
	}

	@Override
	public Role getRoleById(int id) {
		return roleDao.getRoleById(id);
	}

}

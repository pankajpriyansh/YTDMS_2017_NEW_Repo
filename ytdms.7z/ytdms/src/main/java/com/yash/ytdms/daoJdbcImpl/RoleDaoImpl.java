package com.yash.ytdms.daoJdbcImpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.yash.ytdms.dao.RoleDao;
import com.yash.ytdms.model.Role;

/**
 * 
 * @author goyal.ayush
 *
 */
@Repository
public class RoleDaoImpl implements RoleDao {
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;

	public DataSource getDataSource() {
		return dataSource;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<Role> getAllRoles() {
		return jdbcTemplate.query("select * from roles", new RoleRowMapper());
	}

	private static final class RoleRowMapper implements RowMapper<Role> {

		public Role mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			Role role = new Role();
			role.setId(resultSet.getInt("id"));
			role.setName(resultSet.getString("name"));
			return role;
		}
	}

	@Override
	public Role getRoleById(int id) {
		return jdbcTemplate.queryForObject("select * from roles where id=?",
				new Object[] { id }, new RoleRowMapper());
	}

}

package com.yash.ytdms.serviceImpl;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ytdms.dao.CategoryDao;
import com.yash.ytdms.model.Category;
import com.yash.ytdms.service.CategoryService;
import com.yash.ytdms.service.SectionService;

/**
 * CategoryServiceImpl is the implementation of all the services and
 * functionalities related to Category. It contains all the services related to
 * business logics. Whenever there is a need of database , it can have a call to
 * DAO , to fulfill the need.
 * 
 * @author goyal.ayush
 *
 */
@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryDao categoryDao;

	@Autowired
	private SectionService sectionService;

	public List<Category> getCategoriesBySectionId(int sectionId) {
		return categoryDao.getCategoriesBySectionId(sectionId);
	}

	@Override
	public boolean checkIfCategoryExists(String name, int section_id) {
		return categoryDao.checkIfCategoryExists(name, section_id);
	}

	@Override
	public void makeCategoryNameFolder(String workingDir, int sectionId,
			String categoryName) {
		String sectionName = sectionService
				.getSectionNameBySectionId(sectionId);
		System.out.println("Current working directory : " + workingDir);
		File pathToMakeCategoryDir = new File(workingDir + File.separator
				+ ".." + File.separator + "ytdms-cli" + File.separator
				+ "assets" + File.separator + "Documents" + File.separator
				+ sectionName + File.separator + categoryName);
		if (!pathToMakeCategoryDir.exists()) {
			pathToMakeCategoryDir.mkdirs();
			System.out
					.println("--------------- Category Directory Made -------------");
		}
	}

	@Override
	public void addCategory(Category category) {
		categoryDao.addCategory(category);

	}

}

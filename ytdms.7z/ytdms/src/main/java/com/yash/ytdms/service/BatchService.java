package com.yash.ytdms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.yash.ytdms.model.Batch;

/**
 * 
 * @author goyal.ayush
 *
 */
@Service
public interface BatchService {
	List<Batch> getAllBatches();

	boolean checkIfBatchExists(String name);

	void addBatch(Batch batch);

	int getTotalBatches();

}

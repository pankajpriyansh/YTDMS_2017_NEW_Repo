package com.yash.ytdms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ytdms.model.Batch;
import com.yash.ytdms.model.Member;
import com.yash.ytdms.service.BatchService;

/**
 * Used for the services that are related to Batches
 * 
 * @author goyal.ayush
 *
 */
@RestController
@RequestMapping("/batches")
@CrossOrigin(origins = "*")
public class BatchController {
	@Autowired
	private BatchService batchService;
	@Autowired
	private Member loggedInUser;

	/**
	 * 
	 * @return all the batches available in batches table
	 * @throws IOException
	 */
	@GetMapping(value = "/")
	public List<Batch> getBatches() throws IOException {
		List<Batch> batches = batchService.getAllBatches();
		return batches;
	}

	/**
	 * need to give batch name only
	 * 
	 * @param batchName
	 * @param session
	 * @param response
	 * @param request
	 * @throws IOException
	 */
	@PostMapping("/saveBatch")
	@ResponseBody
	public void saveBatch(@RequestBody Batch batch, HttpSession session,
			HttpServletResponse response, HttpServletRequest request)
			throws IOException {
		if (batchService.checkIfBatchExists(batch.getName())) {
			response.getWriter().append("batchExists");
			return;
		}
		batch.setCreatedBy(loggedInUser.getId());
		batch.setModifiedBy(loggedInUser.getId());
		batchService.addBatch(batch);
	}

	@GetMapping("/getTotalBatches")
	public int getTotalBatches() throws IOException {
		return batchService.getTotalBatches();
	}
}

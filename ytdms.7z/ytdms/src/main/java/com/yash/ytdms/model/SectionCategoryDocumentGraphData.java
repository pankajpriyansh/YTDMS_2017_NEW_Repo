package com.yash.ytdms.model;

import org.springframework.stereotype.Component;

@Component
public class SectionCategoryDocumentGraphData {

	private String sectionName;
	private int totalCategoies;
	private int totalDocuments;

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public int getTotalCategoies() {
		return totalCategoies;
	}

	public void setTotalCategoies(int totalCategoies) {
		this.totalCategoies = totalCategoies;
	}

	public int getTotalDocuments() {
		return totalDocuments;
	}

	public void setTotalDocuments(int totalDocuments) {
		this.totalDocuments = totalDocuments;
	}

}

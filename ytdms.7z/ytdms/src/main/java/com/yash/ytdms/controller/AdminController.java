package com.yash.ytdms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ytdms.service.BatchService;
import com.yash.ytdms.service.DocumentService;
import com.yash.ytdms.service.MemberService;
import com.yash.ytdms.service.SectionService;

/**
 * This controller is used for services related to Training Manager.
 * 
 * @author goyal.ayush
 *
 */
@RestController
@CrossOrigin(origins = "*")
public class AdminController {

	@Autowired
	private MemberService memberService;

	@Autowired
	private SectionService sectionService;

	@Autowired
	private DocumentService documentService;

	@Autowired
	private BatchService batchService;

}

package com.yash.ytdms.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.yash.ytdms.model.Batch;

/**
 * 
 * @author goyal.ayush
 *
 */
@Repository
public interface BatchDao {

	List<Batch> getAllBatches();

	boolean checkIfBatchExists(String name);

	void addBatch(Batch batch);

	int getTotalBatches();

}
